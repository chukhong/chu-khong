listCache = listCache.concat(["/chu-khong/Dicts/bktd-dv.zip",
"/chu-khong/Dicts/Dinh%20Phuc%20Bao.zip"])