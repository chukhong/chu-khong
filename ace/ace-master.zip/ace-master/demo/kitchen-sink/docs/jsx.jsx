import * as React from "react";

export default () => {
  return (
    <div variant="p">
      Keywords here are not highlighted, for example class or instance.
    </div>
  );
}